//************************************  PROGRAM IDENTIFICATION  ***************************************
//*                                                                                                   *
//*   PROGRAM FILE NAME:  Project1.cpp          ASSIGNMENT #: 1            Grade: _________          *
//*                                                                                                   *
//*   PROGRAM AUTHOR:             Roberto Mourra                                                      *
//*                   ___________________________________________________                             *
//*                                                                                                   *
//*                                                                                                   *
//*   COURSE #:  CSC 24400 11                              DUE DATE: September 22, 2019               *
//*                                                                                                   *
//*****************************************************************************************************
//***********************************  PROGRAM DESCRIPTION  *******************************************
//*                                                                                                   *
//* PROCESS: This program is designed to print out several tickets for every vehicle category.        *
//* The ticket will show the user how much time the person was inside, what kind of vehicle is, and   *
//* how much money is owed.                                                                           *
//*****************************************************************************************************


#include <iostream>
#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <iomanip>
using namespace std; 
void header(ofstream&);  //prototype for method Header
void Footer(ofstream&);  //prototype for method footer.
void readIn(ifstream&, ofstream&); // prototype for method ReadIn
void calculateTicket(); // protype used to calculate ticket.
void printTicket(ofstream&); // prototype for print method.
bool dbm = true; // boolean that is set equal to true.
bool footer = true; // boolean that is set equal to false.
char CarDenom; // selects which type of vehicle is.
int enterTime, Out; // int numbers of time entered and out.
double ti, to; // double variable for time in and out because it can be a decimal number.
double THours; // double variable for total hours because it can be a decimal number.
double Fee; // double variable for total fee because it can be a decimal number.


int main() // main body.
{
    
    ifstream infile("DATA1.txt", ios::in); // this method allows to read data from a file.
    ofstream outfile("ticket.txt", ios::out); // this method allows to store an output in a new file.
    
    header(outfile);
    
    while(dbm == true)
    {
        readIn(infile, outfile);// read in the file from data1.txt and stores it in ticket.txt.
        calculateTicket(); // calculates the ticket.
        printTicket(outfile); // prints the actual ticket.
        
    }
    while (footer == true)
    {
        footer = false; // exits the while loop.
    }
    return 0;
}

// method that returns nothing and read the file and stores it in the new file.
void readIn(ifstream &infile, ofstream &outfile)
{
    infile >> CarDenom;
    if (CarDenom == 'X')
    {
        dbm = false;
        Footer(outfile);
        cin.get();
    }
    if (CarDenom != 'X')
    {
        infile >> enterTime;
        infile >> Out;
    }
}

// method that takes no paraments and return nothing used to calculate the ticket.
void calculateTicket()
{
    ti = enterTime;
    to = Out;
    THours = ((to - ti) / 60);
    THours = ceil(THours);
    
    if (CarDenom == 'C')
    {
        if (THours <= 2)
            Fee = THours * 0.20;
        
        else if (THours>2 && THours <= 5)
            Fee = 2 * 0.2 + (THours - 2) * 0.15;
        
        else
            Fee = 2 * 0.2 + 3 * 0.15 + (THours - 5) * 0.05;
        
    }
    else if (CarDenom == 'T')
    {
        if (THours <= 1)
            Fee = THours * 0.40;
        else if (THours <= 4)
            Fee = 1 * 0.40 + (THours - 1) * 0.25;
        else
            Fee = 2 * 0.2 + 3 * 0.15 + (THours - 5) * 0.05;
        
    }
    else if (CarDenom == 'S')
    {
        Fee = THours * 0.12;
        
    }
}


// this method is used to print the ticket and it shows the category, time, and amount paid.
void printTicket(ofstream &outfile)
{
    outfile << "The input data was : " << endl;
    outfile << "$$$$$$$$$$$$$$$$$$$$$$$$$$$" << endl;
    outfile << "$                         $" << endl;
    outfile << "$     Missouri Western    $" << endl;
    outfile << "$        University       $" << endl;
    outfile << "$$$$$$$$$$$$$$$$$$$$$$$$$$$" << endl;
    outfile << "$       Parking Fee       $" << endl;
    outfile << "$                         $" << endl;
    outfile << "$ Customer                $" << endl;
    outfile << "$ CATEGORY: "<<CarDenom<<"$" << endl;
    outfile << "$ TIME:"<< THours <<     "$" << endl;
    outfile << "$                         $" << endl;
    outfile << "$ AMOUNT                  $" << endl;
    outfile << "$ PAID:$" << Fee <<      "$" << endl;
    outfile << "$                         $" << endl;
    outfile << "$$$$$$$$$$$$$$$$$$$$$$$$$$$" << endl;
    outfile << " " << endl;
}

void header( ofstream &outfile)
{
    // Receives – the output file
    // Task - Prints the output preamble
    // Returns - Nothing
    outfile << setw(30) << "Roberto Mourra";
    outfile << setw(17) << "CSC 24400";
    outfile << setw(15) << "Section 11" << endl;
    outfile << setw(30) << "Fall 2019";
    outfile << setw(20) << "Assignment # 1" << endl;
    outfile << setw(35) << "---------------------------------- - ";
    outfile << setw(35) << "---------------------------------- - " << endl << endl;
    return;
}
//************************************* END OF FUNCTION HEADER  ****************************************

void Footer( ofstream &outfile)
{
    // Receives – the output file
    // Task - Prints the output salutation
    // Returns - Nothing
    outfile << endl;
    outfile << setw(35) << "-------------------------------- - " << endl;
    outfile << setw(35) << "     | END OF PROGRAM OUTPUT |     " << endl;
    outfile << setw(35) << "-------------------------------- - " << endl;
    
    return;
}
//************************************* END OF FUNCTION FOOTER  ****************************************
